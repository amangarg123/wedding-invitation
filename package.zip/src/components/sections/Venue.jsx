import { ExternalLink, MapPin } from "lucide-react";

import Reveal from "../Reveal";
import PhotoPlaceholder from "../PhotoPlaceholder";

import { ROSE } from "../../styles/theme";

export default function Venue() {
  return (
    <section style={{ padding: "3rem 1.5rem" }}>
        <p style={{ textAlign: "center", color: ROSE.textSoft, fontSize: 14, marginBottom: 20 }}>
          Join us at our beautiful wedding venue
        </p>
        <div style={{ maxWidth: 380, margin: "0 auto" }}>
          <Reveal>
            <div style={{ background: ROSE.bg, borderRadius: 16, padding: "18px 20px", marginBottom: 16 }}>
              <div style={{ fontWeight: 600, fontSize: 16 }}>Venue name</div>
              <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 13, color: ROSE.textSoft, marginTop: 6 }}>
                <MapPin size={13} /> City, state
              </div>
              <button
                style={{
                  marginTop: 14,
                  width: "100%",
                  padding: "12px 0",
                  borderRadius: 10,
                  border: "none",
                  background: `linear-gradient(90deg, ${ROSE.gradientA}, ${ROSE.gradientB})`,
                  color: "#fff",
                  fontWeight: 500,
                  fontSize: 13,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 6,
                  cursor: "pointer",
                }}
              >
                Get directions <ExternalLink size={13} />
              </button>
            </div>
          </Reveal>
          <Reveal delay={0.1}>
            <div style={{ borderRadius: 16, overflow: "hidden", border: `1px solid ${ROSE.line}` }}>
              <PhotoPlaceholder ratio="4/3" label="Map preview" />
            </div>
          </Reveal>
        </div>
      </section>
  );
}